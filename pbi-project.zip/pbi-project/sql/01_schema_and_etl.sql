/* =========================================================================
   HR Workforce Analytics - Star Schema DDL + ETL
   Portable T-SQL / PostgreSQL-flavored syntax (minor tweaks per engine noted)
   ========================================================================= */

-- ---------------------------------------------------------------
-- 1. STAGING: raw load exactly as it lands from the source system
--    (this mirrors what an HRIS export would look like: messy)
-- ---------------------------------------------------------------
CREATE TABLE stg_employee_raw (
    EmployeeID       VARCHAR(10),
    EmployeeName     VARCHAR(100),
    Gender_raw       VARCHAR(20),      -- inconsistent casing/whitespace, e.g. ' Male ', 'FEMALE'
    Age              INT,
    MaritalStatus    VARCHAR(20),      -- contains NULLs
    Education        VARCHAR(20),
    DepartmentID     VARCHAR(5),
    JobRole          VARCHAR(50),
    GeographyID      VARCHAR(5),
    HireDate         DATE,
    TerminationDate  DATE NULL,
    MonthlyIncome    DECIMAL(10,2),
    JobSatisfaction  INT
);

-- ---------------------------------------------------------------
-- 2. DIMENSION TABLES (cleaned, conformed)
-- ---------------------------------------------------------------
CREATE TABLE DimDepartment (
    DepartmentID    VARCHAR(5) PRIMARY KEY,
    DepartmentName  VARCHAR(50) NOT NULL,
    DivisionName    VARCHAR(50) NOT NULL
);

CREATE TABLE DimGeography (
    GeographyID  VARCHAR(5) PRIMARY KEY,
    Region       VARCHAR(20) NOT NULL,
    Country      VARCHAR(50) NOT NULL,
    City         VARCHAR(50) NOT NULL
);

CREATE TABLE DimDate (
    DateKey     DATE PRIMARY KEY,
    Year        INT NOT NULL,
    MonthNum    INT NOT NULL,
    MonthName   VARCHAR(3) NOT NULL,
    Quarter     VARCHAR(2) NOT NULL,
    YearMonth   VARCHAR(7) NOT NULL
);

CREATE TABLE DimEmployee (
    EmployeeID       VARCHAR(10) PRIMARY KEY,
    EmployeeName     VARCHAR(100) NOT NULL,
    Gender           VARCHAR(10) NOT NULL,
    Age              INT NOT NULL,
    MaritalStatus    VARCHAR(20) NOT NULL,   -- nulls resolved to 'Not Disclosed'
    Education        VARCHAR(20),
    DepartmentID     VARCHAR(5) REFERENCES DimDepartment(DepartmentID),
    JobRole          VARCHAR(50),
    GeographyID      VARCHAR(5) REFERENCES DimGeography(GeographyID),
    HireDate         DATE NOT NULL,
    TerminationDate  DATE NULL,
    MonthlyIncome    DECIMAL(10,2),
    JobSatisfaction  INT
);

-- ---------------------------------------------------------------
-- 3. FACT TABLE (monthly grain -> enables time-intelligence DAX)
--    One row per employee per active month = a "snapshot fact".
--    AttritionFlag = 1 only in the month the employee left.
-- ---------------------------------------------------------------
CREATE TABLE FactHeadcount (
    FactID           BIGINT PRIMARY KEY,
    DateKey          DATE REFERENCES DimDate(DateKey),
    EmployeeID       VARCHAR(10) REFERENCES DimEmployee(EmployeeID),
    DepartmentID     VARCHAR(5) REFERENCES DimDepartment(DepartmentID),
    GeographyID      VARCHAR(5) REFERENCES DimGeography(GeographyID),
    HeadcountFlag    INT NOT NULL,      -- always 1; sums to headcount
    AttritionFlag    INT NOT NULL,      -- 1 in the employee's final month only
    MonthlyIncome    DECIMAL(10,2),
    JobSatisfaction  INT
);

CREATE INDEX idx_fact_employee  ON FactHeadcount(EmployeeID);
CREATE INDEX idx_fact_date      ON FactHeadcount(DateKey);
CREATE INDEX idx_fact_dept      ON FactHeadcount(DepartmentID);

-- ---------------------------------------------------------------
-- 4. ETL: cleanse staging -> DimEmployee
--    This is the SQL-side equivalent of the Power Query steps
--    documented in /powerquery/transformations.md
-- ---------------------------------------------------------------
INSERT INTO DimEmployee (
    EmployeeID, EmployeeName, Gender, Age, MaritalStatus, Education,
    DepartmentID, JobRole, GeographyID, HireDate, TerminationDate,
    MonthlyIncome, JobSatisfaction
)
SELECT
    EmployeeID,
    EmployeeName,
    -- standardize inconsistent casing/whitespace: ' Male ' / 'FEMALE' -> 'Male' / 'Female'
    INITCAP(TRIM(Gender_raw))                          AS Gender,
    Age,
    COALESCE(MaritalStatus, 'Not Disclosed')            AS MaritalStatus,
    Education,
    DepartmentID,
    JobRole,
    GeographyID,
    HireDate,
    TerminationDate,
    MonthlyIncome,
    JobSatisfaction
FROM stg_employee_raw;
-- NOTE: INITCAP is Postgres/Oracle syntax. In T-SQL use:
--   UPPER(LEFT(LTRIM(RTRIM(Gender_raw)),1)) + LOWER(SUBSTRING(LTRIM(RTRIM(Gender_raw)),2,LEN(Gender_raw)))

-- ---------------------------------------------------------------
-- 5. Example analytical query the fact table is designed to answer
--    (attrition rate by department, most recent completed month)
-- ---------------------------------------------------------------
SELECT
    d.DepartmentName,
    COUNT(DISTINCT CASE WHEN f.HeadcountFlag = 1 THEN f.EmployeeID END)  AS Headcount,
    SUM(f.AttritionFlag)                                                 AS Departures,
    ROUND(1.0 * SUM(f.AttritionFlag) /
          NULLIF(COUNT(DISTINCT f.EmployeeID), 0), 4)                   AS AttritionRate
FROM FactHeadcount f
JOIN DimDepartment d ON d.DepartmentID = f.DepartmentID
WHERE f.DateKey = (SELECT MAX(DateKey) FROM FactHeadcount)
GROUP BY d.DepartmentName
ORDER BY AttritionRate DESC;
