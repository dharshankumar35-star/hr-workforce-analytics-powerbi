# Row-Level Security (RLS) Setup

Goal: a "Regional Manager" role should only see data for their own region when they open
the published report — without needing separate reports per region.

## Steps in Power BI Desktop

1. **Modeling tab > Manage Roles > Create Role**, name it `RegionalManager`.
2. Select the `DimGeography` table and add this filter expression (DAX):

```dax
[Region] = USERPRINCIPALNAME ()
```

Since `USERPRINCIPALNAME()` returns the logged-in user's email, the practical pattern is a
**mapping table** rather than hardcoding region names against emails:

```dax
DimGeography[Region] IN
    CALCULATETABLE (
        VALUES ( RegionUserMapping[Region] ),
        RegionUserMapping[UserEmail] = USERPRINCIPALNAME ()
    )
```

3. Add a small `RegionUserMapping` table to the model (2 columns: `UserEmail`, `Region`) —
   this is the standard way real RLS is implemented, since you rarely want DAX filters
   hardcoded to a single literal value.

4. **Modeling tab > View As** to test the role before publishing — pick `RegionalManager`
   and confirm visuals filter down to one region only.

5. After publishing to **Power BI Service**: go to the workspace, dataset **Security**
   settings, and assign actual user accounts (or an Azure AD security group) to the
   `RegionalManager` role. Desktop-defined roles don't auto-assign users — that's a
   Service-side step, which is itself worth mentioning in an interview since it's a common
   gap in candidates who only test RLS in Desktop.

## Why RLS matters for this JD

Row-Level Security is one of the most commonly asked Power BI interview questions
("how would you make sure a manager only sees their own team's data?") and one of the
least commonly *actually implemented* by junior candidates, since it requires no visible
visual change — it's easy to skip. Having it built and being able to explain the
`USERPRINCIPALNAME()` + mapping-table pattern is a meaningful signal.
