"""
Generates a synthetic HR Workforce Analytics dataset, structured as a star schema:
  DimEmployee, DimDepartment, DimGeography, DimDate, FactHeadcount

Designed specifically to require real Power BI Developer skills:
- FactHeadcount is at MONTHLY grain per employee -> enables time-intelligence DAX
  (YTD, YoY, rolling averages, cumulative headcount)
- DimGeography enables Row-Level Security by Region
- Includes intentional data-quality issues (nulls, inconsistent casing) so
  Power Query cleanup steps are genuine, not decorative
"""
import pandas as pd
import numpy as np
from faker import Faker
import random
from datetime import date, timedelta

random.seed(42)
np.random.seed(42)
fake = Faker()
Faker.seed(42)

N_EMPLOYEES = 320

departments = [
    ("D01", "Sales", "Revenue"),
    ("D02", "Engineering", "Product & Tech"),
    ("D03", "Customer Support", "Operations"),
    ("D04", "Human Resources", "Corporate"),
    ("D05", "Finance", "Corporate"),
    ("D06", "Marketing", "Revenue"),
]
dim_department = pd.DataFrame(departments, columns=["DepartmentID", "DepartmentName", "DivisionName"])

geographies = [
    ("G01", "South", "India", "Chennai"),
    ("G02", "South", "India", "Bengaluru"),
    ("G03", "North", "India", "Delhi NCR"),
    ("G04", "West", "India", "Mumbai"),
    ("G05", "West", "India", "Pune"),
    ("G06", "East", "India", "Kolkata"),
]
dim_geography = pd.DataFrame(geographies, columns=["GeographyID", "Region", "Country", "City"])

job_roles_by_dept = {
    "D01": ["Sales Executive", "Account Manager", "Sales Manager"],
    "D02": ["Software Engineer", "Senior Engineer", "QA Engineer", "Engineering Manager"],
    "D03": ["Support Associate", "Support Team Lead"],
    "D04": ["HR Generalist", "Talent Acquisition Specialist", "HR Manager"],
    "D05": ["Financial Analyst", "Accountant", "Finance Manager"],
    "D06": ["Marketing Associate", "Content Strategist", "Marketing Manager"],
}

education_levels = ["Bachelors", "Masters", "PhD", "Diploma"]
marital_status = ["Single", "Married", "Divorced"]

employees = []
today = date(2026, 9, 1)
start_window = date(2019, 1, 1)

for i in range(1, N_EMPLOYEES + 1):
    emp_id = f"E{i:04d}"
    dept_id = random.choice(dim_department["DepartmentID"])
    geo_id = random.choice(dim_geography["GeographyID"])
    role = random.choice(job_roles_by_dept[dept_id])
    gender = random.choice(["Male", "Female"])
    # intentional inconsistent casing / whitespace for Power Query cleanup demo
    gender_raw = random.choice([gender, gender.upper(), f" {gender} "])
    age = random.randint(22, 58)
    hire_date = fake.date_between(start_date=start_window, end_date=date(2025, 12, 1))

    # ~17% attrition rate, weighted toward lower tenure and certain depts
    attrition_prob = 0.17
    if dept_id in ("D01", "D03"):
        attrition_prob += 0.06
    will_leave = random.random() < attrition_prob

    term_date = None
    if will_leave:
        max_days = (today - hire_date).days
        if max_days > 60:
            term_offset = random.randint(60, max_days)
            term_date = hire_date + timedelta(days=term_offset)

    monthly_income = int(np.random.normal(
        {"D01": 55000, "D02": 85000, "D03": 40000, "D04": 50000, "D05": 60000, "D06": 52000}[dept_id],
        8000
    ))
    monthly_income = max(monthly_income, 22000)

    job_satisfaction = random.randint(1, 4)  # 1=Low ... 4=Very High
    education = random.choice(education_levels)
    # intentional missing values (~4%) for Power Query null-handling demo
    marital = random.choice(marital_status) if random.random() > 0.04 else None

    employees.append({
        "EmployeeID": emp_id,
        "EmployeeName": fake.name(),
        "Gender_raw": gender_raw,
        "Age": age,
        "MaritalStatus": marital,
        "Education": education,
        "DepartmentID": dept_id,
        "JobRole": role,
        "GeographyID": geo_id,
        "HireDate": hire_date,
        "TerminationDate": term_date,
        "MonthlyIncome": monthly_income,
        "JobSatisfaction": job_satisfaction,
    })

dim_employee = pd.DataFrame(employees)

# ---- DimDate (monthly grain, spans dataset range) ----
all_months = pd.date_range("2019-01-01", "2026-09-01", freq="MS")
dim_date = pd.DataFrame({"DateKey": all_months})
dim_date["Year"] = dim_date["DateKey"].dt.year
dim_date["MonthNum"] = dim_date["DateKey"].dt.month
dim_date["MonthName"] = dim_date["DateKey"].dt.strftime("%b")
dim_date["Quarter"] = "Q" + dim_date["DateKey"].dt.quarter.astype(str)
dim_date["YearMonth"] = dim_date["DateKey"].dt.strftime("%Y-%m")

# ---- FactHeadcount: one row per employee per active month ----
fact_rows = []
fid = 1
for _, e in dim_employee.iterrows():
    hire_month = pd.Timestamp(e["HireDate"]).to_period("M").to_timestamp()
    end_month = pd.Timestamp(e["TerminationDate"]).to_period("M").to_timestamp() if pd.notnull(e["TerminationDate"]) else pd.Timestamp(today).to_period("M").to_timestamp()
    months = pd.date_range(hire_month, end_month, freq="MS")
    for m in months:
        is_last_month = (m == end_month) and pd.notnull(e["TerminationDate"])
        fact_rows.append({
            "FactID": fid,
            "DateKey": m,
            "EmployeeID": e["EmployeeID"],
            "DepartmentID": e["DepartmentID"],
            "GeographyID": e["GeographyID"],
            "HeadcountFlag": 1,
            "AttritionFlag": 1 if is_last_month else 0,
            "MonthlyIncome": e["MonthlyIncome"],
            "JobSatisfaction": e["JobSatisfaction"],
        })
        fid += 1

fact_headcount = pd.DataFrame(fact_rows)

# ---- write outputs ----
dim_employee.to_csv("/home/claude/pbi-project/data/DimEmployee.csv", index=False)
dim_department.to_csv("/home/claude/pbi-project/data/DimDepartment.csv", index=False)
dim_geography.to_csv("/home/claude/pbi-project/data/DimGeography.csv", index=False)
dim_date.to_csv("/home/claude/pbi-project/data/DimDate.csv", index=False)
fact_headcount.to_csv("/home/claude/pbi-project/data/FactHeadcount.csv", index=False)

print("Employees:", len(dim_employee))
print("Fact rows:", len(fact_headcount))
print("Attrition count:", dim_employee["TerminationDate"].notnull().sum())
print("Date range:", dim_date["DateKey"].min(), "to", dim_date["DateKey"].max())
