# Build Guide — HR Workforce Analytics (Power BI Desktop)

This is the assembly guide. The data, SQL, Power Query M, DAX, and RLS logic are all
already written for you in this repo — this is the "click it together in Power BI Desktop"
part, which needs the actual application.

## 1. Get the data model into Power BI Desktop

**Option A — quickest (CSV import):**
- Open Power BI Desktop > **Get Data > Text/CSV**
- Import each file from `/data/`: `DimEmployee.csv`, `DimDepartment.csv`,
  `DimGeography.csv`, `DimDate.csv`, `FactHeadcount.csv`
- Apply the cleanup steps from `/powerquery/transformations.md` to `DimEmployee` and
  `FactHeadcount` via the Advanced Editor

**Option B — more impressive in an interview (SQL import):**
- Open Power BI Desktop > **Get Data > SQLite database** (or ODBC), point it at
  `/data/hr_workforce.db`
- This lets you say "I connected Power BI directly to a SQL data source" rather than
  "I imported CSVs" — a real distinction interviewers ask about
- The same `.db` file already has both `stg_employee_raw` (messy) and the cleaned
  `DimEmployee`/`FactHeadcount` tables, built by `/sql/01_schema_and_etl.sql` — you can
  choose to import the staging table and do the cleanup live in Power Query to demonstrate
  the full pipeline, or import the cleaned tables directly

## 2. Build the model relationships

In **Model view**, connect:
- `FactHeadcount[DateKey]` → `DimDate[DateKey]` (many-to-one)
- `FactHeadcount[EmployeeID]` → `DimEmployee[EmployeeID]` (many-to-one)
- `FactHeadcount[DepartmentID]` → `DimDepartment[DepartmentID]` (many-to-one)
- `FactHeadcount[GeographyID]` → `DimGeography[GeographyID]` (many-to-one)

Mark `DimDate` as a **Date Table** (Modeling tab > Mark as Date Table) — required for the
time-intelligence DAX functions to work correctly.

## 3. Add the DAX measures

Create a measures table (Home > Enter Data, one blank column, name it `_Measures`), then
paste in each formula from `/dax/measures.md`.

## 4. Build the report pages

**Page 1 — Executive Overview**
- KPI cards: Total Headcount, Attrition Rate, Avg Monthly Income
- Line chart: Total Headcount by month (use `DimDate[YearMonth]` on axis)
- Bar chart: Headcount by Department
- Donut: Headcount by Region

**Page 2 — Attrition Deep Dive**
- Bar chart: Attrition Rate by Department (sorted using `Department Rank by Attrition`)
- Line chart: Headcount YoY % over time
- Table: Department, Headcount, Departures, Attrition Rate — with conditional formatting
  on Attrition Rate (data bars or color scale)
- Drill-through: right-click a department bar → drill through to a filtered employee list

**Page 3 — Regional Manager View (RLS demo)**
- Same KPIs as Page 1, filtered by Region slicer
- Apply the RLS role from `/docs/row_level_security.md` and use **View As** to demonstrate
  it filters correctly before publishing

## 5. Publish

- **Home > Publish** to a Power BI Service workspace
- In the Service: **Dataset Settings > Security**, assign a test user/group to the
  `RegionalManager` role
- If you have a scheduled-refreshable source (SQL Server/Postgres in the cloud, not
  SQLite/local CSV), set up a **Scheduled Refresh** — if not, note in your README that
  this was configured conceptually against the SQL layer, since Power BI Service can't
  refresh a local SQLite file

## 6. What to put on GitHub

- `/data`, `/sql`, `/powerquery`, `/dax`, `/docs` (everything in this folder)
- Export a few screenshots of the finished report pages into `/screenshots`
- The `.pbix` file itself (Power BI Desktop's File > Save)
- The README already drafted for you — see `/docs/README.md`
