# Power Query (M) Transformations

Apply these in Power BI Desktop: **Home > Transform Data**, select the query, then
**Home > Advanced Editor** to paste/inspect the M code. Each block below is one query.

---

## 1. `DimEmployee` — cleanup query

Source: `DimEmployee.csv` (or the `stg_employee_raw` SQL table if connecting via SQL import).

```m
let
    Source = Csv.Document(File.Contents("DimEmployee.csv"), [Delimiter=",", Columns=13, Encoding=1252, QuoteStyle=QuoteStyle.None]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    ChangedType = Table.TransformColumnTypes(PromotedHeaders, {
        {"EmployeeID", type text}, {"EmployeeName", type text}, {"Gender_raw", type text},
        {"Age", Int64.Type}, {"MaritalStatus", type text}, {"Education", type text},
        {"DepartmentID", type text}, {"JobRole", type text}, {"GeographyID", type text},
        {"HireDate", type date}, {"TerminationDate", type date},
        {"MonthlyIncome", type number}, {"JobSatisfaction", Int64.Type}
    }),

    // Step: standardize inconsistent text -> ' Male ' / 'FEMALE' both become 'Male' / 'Female'
    TrimmedGender = Table.TransformColumns(ChangedType, {{"Gender_raw", Text.Trim, type text}}),
    ProperGender = Table.TransformColumns(TrimmedGender, {{"Gender_raw", Text.Proper, type text}}),
    RenamedGender = Table.RenameColumns(ProperGender, {{"Gender_raw", "Gender"}}),

    // Step: null handling — replace blank MaritalStatus with an explicit category
    // (never silently drop rows with nulls — that skews headcount)
    FilledMarital = Table.ReplaceValue(RenamedGender, null, "Not Disclosed",
        Replacer.ReplaceValue, {"MaritalStatus"}),

    // Step: conditional column — derive employment status directly in the query
    AddedStatus = Table.AddColumn(FilledMarital, "EmploymentStatus", each
        if [TerminationDate] = null then "Active" else "Terminated", type text),

    // Step: derive tenure in months (used to validate against DAX tenure measure)
    AddedTenure = Table.AddColumn(AddedStatus, "TenureMonths", each
        Duration.Days(([TerminationDate] ?? Date.From(DateTime.LocalNow())) - [HireDate]) / 30, type number)
in
    AddedTenure
```

---

## 2. `FactHeadcount` — merge + conditional column example

Demonstrates a **merge (join)** in Power Query, which is a common interview ask.

```m
let
    Source = Csv.Document(File.Contents("FactHeadcount.csv"), [Delimiter=",", Columns=8, Encoding=1252]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    ChangedType = Table.TransformColumnTypes(PromotedHeaders, {
        {"FactID", Int64.Type}, {"DateKey", type date}, {"EmployeeID", type text},
        {"DepartmentID", type text}, {"GeographyID", type text},
        {"HeadcountFlag", Int64.Type}, {"AttritionFlag", Int64.Type},
        {"MonthlyIncome", type number}, {"JobSatisfaction", Int64.Type}
    }),

    // Merge in Department name so a slicer/visual doesn't need a relationship hop
    // (only do this if you specifically need denormalized fields — normally keep the star schema intact
    //  and let relationships handle it; this is shown for interview demonstration purposes)
    MergedDept = Table.NestedJoin(ChangedType, {"DepartmentID"}, DimDepartment, {"DepartmentID"}, "DeptTable", JoinKind.LeftOuter),
    ExpandedDept = Table.ExpandTableColumn(MergedDept, "DeptTable", {"DepartmentName"}, {"DepartmentName"}),

    // Conditional column: income band, used for a distribution visual
    AddedIncomeBand = Table.AddColumn(ExpandedDept, "IncomeBand", each
        if [MonthlyIncome] < 40000 then "Under 40K"
        else if [MonthlyIncome] < 60000 then "40K-60K"
        else if [MonthlyIncome] < 80000 then "60K-80K"
        else "80K+", type text)
in
    AddedIncomeBand
```

---

## 3. Unpivot example (for a wide "monthly satisfaction survey" extension)

If you extend the project with a wide survey export (one column per month), this is the
standard unpivot pattern interviewers look for:

```m
let
    Source = Excel.Workbook(File.Contents("SatisfactionSurveyWide.xlsx"), null, true),
    Sheet1 = Source{[Item="Survey",Kind="Sheet"]}[Data],
    PromotedHeaders = Table.PromoteHeaders(Sheet1, [PromoteAllScalars=true]),
    UnpivotedMonths = Table.UnpivotOtherColumns(PromotedHeaders, {"EmployeeID"}, "Month", "SatisfactionScore")
in
    UnpivotedMonths
```

---

## Why this matters for the interview

A Power BI Developer role tests whether you clean data **in Power Query**, not by
pre-cleaning it in Excel before import. Be ready to explain each step above out loud:
what problem it fixes, and why you chose that step type over an alternative (e.g., why
`Table.ReplaceValue` for nulls instead of filtering rows out).
