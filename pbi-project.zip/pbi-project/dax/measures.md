# DAX Measures — HR Workforce Analytics

Create these under a dedicated **Measures table** (best practice: `New Table` with a single
column, hide it from Report view, and organize measures there instead of scattering them
across DimEmployee/FactHeadcount — this itself is a thing interviewers notice).

---

## Core measures

```dax
Total Headcount =
SUM ( FactHeadcount[HeadcountFlag] )
```

```dax
Total Departures =
SUM ( FactHeadcount[AttritionFlag] )
```

```dax
Attrition Rate =
DIVIDE ( [Total Departures], [Total Headcount], 0 )
```
*Uses `DIVIDE` instead of `/` — avoids a divide-by-zero error when a filter context returns
zero headcount (e.g., a department with no data in a selected month). This is one of the
most common junior-vs-mid-level DAX tells.*

```dax
Avg Monthly Income =
AVERAGE ( FactHeadcount[MonthlyIncome] )
```

---

## Time intelligence

```dax
Headcount YTD =
TOTALYTD ( [Total Headcount], DimDate[DateKey] )
```

```dax
Headcount Same Period Last Year =
CALCULATE (
    [Total Headcount],
    SAMEPERIODLASTYEAR ( DimDate[DateKey] )
)
```

```dax
Headcount YoY % =
VAR CurrentHC = [Total Headcount]
VAR PriorYearHC = [Headcount Same Period Last Year]
RETURN
    DIVIDE ( CurrentHC - PriorYearHC, PriorYearHC )
```

```dax
Rolling 3-Month Avg Headcount =
AVERAGEX (
    DATESINPERIOD ( DimDate[DateKey], MAX ( DimDate[DateKey] ), -3, MONTH ),
    CALCULATE ( [Total Headcount] )
)
```
*Uses `AVERAGEX` over `DATESINPERIOD` rather than a simple average — required whenever the
answer needs to be recalculated per date in context, not just once at the end.*

---

## Filter-context modification with CALCULATE

```dax
Attrition Rate Excl. Sales =
CALCULATE (
    [Attrition Rate],
    DimDepartment[DepartmentName] <> "Sales"
)
```

```dax
Headcount - Active Only =
CALCULATE (
    [Total Headcount],
    FILTER ( DimEmployee, ISBLANK ( DimEmployee[TerminationDate] ) )
)
```
*This pattern — `CALCULATE` + `FILTER` over the full dimension table rather than a simple
boolean column filter — is what interviewers use to test whether you understand row context
vs. filter context, not just measure syntax.*

---

## Ranking

```dax
Department Rank by Attrition =
RANKX (
    ALL ( DimDepartment[DepartmentName] ),
    [Attrition Rate],
    ,
    DESC
)
```
*`ALL()` removes the existing department filter so every department is ranked against the
full set, not just the one in the current row — a frequent RANKX mistake is forgetting this
and getting rank 1 for every row.*

---

## Running total / cumulative

```dax
Cumulative Departures YTD =
CALCULATE (
    [Total Departures],
    FILTER (
        ALL ( DimDate[DateKey] ),
        DimDate[DateKey] <= MAX ( DimDate[DateKey] )
            && YEAR ( DimDate[DateKey] ) = YEAR ( MAX ( DimDate[DateKey] ) )
    )
)
```

---

## Employee tenure (bridges DimEmployee attributes into a measure)

```dax
Avg Tenure (Months) =
AVERAGEX (
    DimEmployee,
    DATEDIFF (
        DimEmployee[HireDate],
        COALESCE ( DimEmployee[TerminationDate], TODAY () ),
        MONTH
    )
)
```

---

## How to talk about these in an interview

Don't just say "I wrote DAX measures." Be ready to explain, for at least 2–3 of the above:
- What filter context is active when the measure evaluates
- Why `CALCULATE` was needed at all (it's the only function that can *modify* filter context)
- Why `DIVIDE` over `/`, and why `RANKX` needs `ALL()` to rank correctly
